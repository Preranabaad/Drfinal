package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.UserDao;
import com.lti.model.Account_details;
import com.lti.model.Beneficiary;
import com.lti.model.Drtransactions;
import com.lti.model.dr_Customers;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao dao;

	public boolean CheckUsername(String username) {
		return dao.CheckUsername(username);
	}

	@Override
	public boolean CheckAccno(long accno) {
		return dao.checkacc(accno);

	}

	@Override
	@Transactional
	public void adduser(long accno, String username, String password, int pin) {
		dao.addaccount(accno, username, password, pin);

	}

	@Override
	@Transactional
	public void readBeneficiary(String bname, long baccno, String bIFSC, String nickname, String username) {
		dao.createBeneficiary(bname, baccno, bIFSC, nickname, username);
	}

	@Override
	@Transactional
	public boolean addCustomer(dr_Customers customer) {
		int result = dao.createCustomer(customer);
		if (result == 1) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public List<Beneficiary> findAllBeneficiary(String username) {
		List<Beneficiary> list = dao.readAllBeneficiary(username);
		return list;

	}

	@Override
	public Beneficiary getbeneficiary(long beneficiaryid) {
		return dao.getbeneficiary(beneficiaryid);
	}

	@Override
	public Account_details getAccount(long custid) {

		return dao.getAccount(custid);
	}

	public String getemail(long custid) {
		return dao.getuseremail(custid);
	}

	@Override
	@Transactional
	public boolean removeAccount(String username) {
		dao.removeUserAccount(username);
		return false;
	}

	@Override
	@Transactional
	public dr_Customers viewCustomer(dr_Customers customer, String username) {
		dr_Customers list = dao.viewCustomer(customer, username);
		return list;
	}

	@Override
	@Transactional
	public boolean updateCustomerDetails(dr_Customers customer, String username) {
		int result = dao.modifyCustomerDetails(customer, username);
		if (result == 1) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public Account_details getIdBalance(String username) {

		return dao.getIdBalance(username);
	}

	@Override
	@Transactional
	public List<Beneficiary> viewAllBeneficiary(String username) {
		List<Beneficiary> list = dao.readAllBeneficiary(username);
		return list;
	}

	@Override
	@Transactional
	public int removeBeneficiary(long beneficiary_Id) {
		int result = dao.deleteBeneficiary(beneficiary_Id);
		return result;
	}

	@Override
	public String getemailbyusername(String username) {
		return dao.getemail(username);
	}

	@Override
	@Transactional
	public List<Drtransactions> readAllTransaction(String username) {
		System.out.println("Inside UserService");
		List<Drtransactions> list= dao.viewAllTransaction(username);
		return list;
	}
	
	

}

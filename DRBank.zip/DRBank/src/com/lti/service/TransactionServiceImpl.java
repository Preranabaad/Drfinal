package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.TransactionDao;
import com.lti.model.Drtransactions;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	private TransactionDao tDao;
	
	@Autowired
	private Drtransactions transactionobj;
	@Override
	public boolean validatepin(int tpin, String username) {
		
		return tDao.validatepin(tpin,username);
		
	}
	@Transactional
	@Override
	public Drtransactions performtransaction(double amount, long benaccno, long accno, String remark,
			String type) {
		transactionobj=tDao.performtransaction(amount,accno,benaccno,remark,type);
	
		return transactionobj;
	}


}

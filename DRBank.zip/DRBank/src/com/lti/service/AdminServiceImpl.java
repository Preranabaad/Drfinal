package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.AdminDao;
import com.lti.model.dr_Customers;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao dao;

	@Transactional
	@Override
	public List<dr_Customers> viewAllUsers() {
		List<dr_Customers> list = dao.readAllUsers();
		return list;
	}

	@Transactional
	@Override
	public List<dr_Customers> validateCustomer() {
		List<dr_Customers> list = dao.validateUsers();
		return list;
	}

	@Transactional
	@Override
	public int setStatus(long customer_id) {
		int result = dao.updateStatus(customer_id);
		if (result == 1) {
			int result1 = dao.addAccountDetails(customer_id);
		}
		return 1;
	}

}

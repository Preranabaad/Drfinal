package com.lti.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Account_details;
import com.lti.model.dr_Customers;
import com.lti.service.AdminService;
import com.lti.service.UserService;



@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminservice;
	
	@Autowired
	private UserService userservice;
	
	@Autowired
	private MailSender mailSender;
	@Autowired
	private SimpleMailMessage message;
	
	@Autowired
	private HttpSession session;
	@Autowired
	private HttpServletRequest request;
	

	//Admin View All customers
@RequestMapping(path="viewallcustomers.do", method=RequestMethod.GET)
	
	public String ViewAllUsers(Model model){
		List<dr_Customers> list=adminservice.viewAllUsers();
		model.addAttribute("customerlist", list);
		return "ViewAllCustomers";
		
	}
	
	//Admin Validate Customers
	@RequestMapping(path="validate.do", method=RequestMethod.GET)
	
	public String validateCustomer(Model model){
		List<dr_Customers> list=adminservice.validateCustomer();
		model.addAttribute("customerlist", list);
		return "ValidateCustomer";
		
	}
	
	//Admin onclick validate from validateCustomer.jsp
	@RequestMapping(path="modifyStatus", method=RequestMethod.GET)
	public String setStatus(@RequestParam("customerid")long customer_id ){
		int result = adminservice.setStatus(customer_id);
		Account_details acc= userservice.getAccount(customer_id);
		String email=userservice.getemail(customer_id);
		
		message.setTo(email); //set a proper recipient of the mail
		message.setSubject("Account Activated Successfully");
		message.setText("Welcome to Dough Rollers Bank! . Your Account is Successfully Activated.!.  Your Account no:"+acc.getAcc_no()+" Go to online Registration Page to register yourself in online banking. Happy Banking!!");
		mailSender.send(message);
		if(result==1){
			return "redirect: validate.do";
		}
		else{
			return "redirect: validate.do";
		}
		
	
	
	}
	
}

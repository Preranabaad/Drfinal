package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Account_details;
import com.lti.model.Beneficiary;
import com.lti.model.Drtransactions;
import com.lti.model.Internet_banking;
import com.lti.model.dr_Customers;

@Repository
public class UserDaoImpl implements UserDao {
	@PersistenceContext
	private EntityManager entityManager;
	@Autowired
	private Internet_banking ib;

	@Autowired
	private Beneficiary beneficiary;

	public boolean CheckUsername(String username) {

		TypedQuery<Internet_banking> tquery = entityManager
				.createQuery("Select a from Internet_banking a where a.username=:u", Internet_banking.class);
		tquery.setParameter("u", username);
		List<Internet_banking> acc = tquery.getResultList();
		if (acc.size() == 0) {
			return true;
		}
		return false;
	}

	@Override
	public boolean checkacc(long accno) {
		TypedQuery<Account_details> tquery = entityManager
				.createQuery("Select a from Account_details a where a.acc_no=:acc", Account_details.class);
		tquery.setParameter("acc", accno);
		List<Account_details> acc = tquery.getResultList();
		if (acc.size() == 0) {
			return true;
		}
		return false;
	}

	@Override
	public void addaccount(long accno, String username, String password, int pin) {
		TypedQuery<Account_details> tquery = entityManager
				.createQuery("Select a from Account_details a where a.acc_no=:acc", Account_details.class);
		tquery.setParameter("acc", accno);
		List<Account_details> acc = tquery.getResultList();
		for (Account_details ac : acc) {
			long cid = ac.getCustomer_id();
			ib.setCustomer_id(cid);
			ib.setLock_status(0);
			ib.setPassword(password);
			ib.setPin(pin);
			ib.setUsername(username);
			entityManager.persist(ib);

		}

	}

	// ADD BENEFICIARY
	@Override
	public void createBeneficiary(String bname, long baccno, String bIFSC, String nickname, String username) {
		TypedQuery<Internet_banking> tquery = entityManager
				.createQuery("Select i from Internet_banking i where i.username=:uname", Internet_banking.class);
		tquery.setParameter("uname", username);
		List<Internet_banking> list = tquery.getResultList();
		for (Internet_banking i : list) {
			long id = i.getCustomer_id();
			beneficiary.setAmount(0);
			beneficiary.setBeneficiary_IFSC(bIFSC);
			beneficiary.setBeneficiary_name(bname);
			beneficiary.setNick_Name(nickname);
			beneficiary.setBeneficiary_Acc_No(baccno);
			beneficiary.setCustomer_Id(id);
			entityManager.persist(beneficiary);
		}
	}

	// OPEN ACCOUNT
	@Override
	public int createCustomer(dr_Customers customer) {
		entityManager.merge(customer);
		return 1;
	}

	@Override
	public List<Beneficiary> readAllBeneficiary(String username) {
		TypedQuery<Internet_banking> tquery = entityManager
				.createQuery("Select i from Internet_banking i where i.username=:uname", Internet_banking.class);
		tquery.setParameter("uname", username);
		List<Internet_banking> list = tquery.getResultList();
		for (Internet_banking i : list) {
			long id = i.getCustomer_id();
			String jpql = "Select b From Beneficiary b where b.customer_Id=:i";
			TypedQuery<Beneficiary> query = entityManager.createQuery(jpql, Beneficiary.class);
			query.setParameter("i", id);
			List<Beneficiary> qlist = query.getResultList();
			return qlist;
		}
		return null;
	}

	@Override
	public Beneficiary getbeneficiary(long beneficiaryid) {
		Beneficiary ben = entityManager.find(Beneficiary.class, beneficiaryid);
		return ben;
	}

	@Override
	public Account_details getAccount(long custid) {
		TypedQuery<Account_details> tquery = entityManager
				.createQuery("Select a from Account_details a where a.customer_id=:id", Account_details.class);
		tquery.setParameter("id", custid);
		Account_details acc = tquery.getSingleResult();
		return acc;
	}

	// OTP

	@Override
	public String getuseremail(long custid) {
		dr_Customers cust = entityManager.find(dr_Customers.class, custid);
		return cust.getEmail();
	}
	//Remove User Account
	@Override
	public boolean removeUserAccount(String username) {
		Internet_banking temp = entityManager.find(Internet_banking.class, username);
		long id = temp.getCustomer_id();
		temp.setLock_status(2);
		TypedQuery<Account_details> tquery = entityManager
				.createQuery("Select i from Account_details i where i.customer_id=:cid", Account_details.class);
		tquery.setParameter("cid", id);
		Account_details temp1 = tquery.getSingleResult();
		temp1.setAcc_status(2);
		entityManager.merge(temp1);
		dr_Customers temp2 = entityManager.find(dr_Customers.class, id);
		temp2.setStatus("2");
		entityManager.merge(temp2);
		return true;
	}
	//Update customer View
	@Override
	public dr_Customers viewCustomer(dr_Customers customer,String username) {
		Internet_banking temp = entityManager.find(Internet_banking.class, username);
		long id = temp.getCustomer_id();
		dr_Customers drcust = entityManager.find(dr_Customers.class, id);

		return drcust;
	}
	//Update Customer Dao code
	@Override
	public int modifyCustomerDetails(dr_Customers customer, String username) {
		Internet_banking temp1= entityManager.find(Internet_banking.class, username);
		long id=temp1.getCustomer_id();
		dr_Customers temp=entityManager.find(dr_Customers.class,id);
		temp.setAadhar_no(customer.getAadhar_no());
		temp.setFirstname(customer.getFirstname());
		temp.setMiddlename(customer.getMiddlename());
		temp.setLastname(customer.getLastname());
		temp.setMobile(customer.getMobile());
		temp.setEmail(customer.getEmail());
		temp.setAadhar_no(customer.getAadhar_no());
		temp.getAadhar_path();
		temp.getPhoto_path();
		temp.setGender(customer.getGender());
		temp.setPERMANENT_ADDRESS(customer.getPERMANENT_ADDRESS());
		temp.setCORRESPONDING_ADDRESS(customer.getCORRESPONDING_ADDRESS());
		entityManager.merge(temp);
		return 1;
	}

	// IMPS
	@Override
	public Account_details getIdBalance(String username) {
		Internet_banking temp = entityManager.find(Internet_banking.class, username);
		long id = temp.getCustomer_id();
		TypedQuery<Account_details> tquery = entityManager
				.createQuery("Select i from Account_details i where i.customer_id=:cid", Account_details.class);
		tquery.setParameter("cid", id);
		Account_details temp1 = tquery.getSingleResult();
		return temp1;
	}

	@Override
	public int deleteBeneficiary(long beneficiary_Id) {
		Beneficiary temp = entityManager.find(Beneficiary.class, beneficiary_Id);

		entityManager.remove(temp);

		return 1;

	}

	@Override
	public String getemail(String username) {
		Internet_banking temp = entityManager.find(Internet_banking.class, username);
		long id = temp.getCustomer_id();
		dr_Customers cust = entityManager.find(dr_Customers.class,id);
		
		return cust.getEmail();
	}
	
	@Override
	public List<Drtransactions> viewAllTransaction(String username) {

		Internet_banking temp=entityManager.find(Internet_banking.class, username );
		long id=temp.getCustomer_id();
		
		TypedQuery<Account_details> tquery1=entityManager.createQuery("select a From Account_details a where a.customer_id=:no ",Account_details.class);
		tquery1.setParameter("no",id);
		Account_details acc=tquery1.getSingleResult();
		long acc_no=acc.getAcc_no();
		TypedQuery<Drtransactions> tquery=entityManager.createQuery("select d From Drtransactions d where d.accNo=:no OR d.bAccNo=:no ORDER BY d.transactionID ",Drtransactions.class);
		tquery.setParameter("no",acc_no);
		List<Drtransactions> list=tquery.getResultList();
		return list;
	}
}

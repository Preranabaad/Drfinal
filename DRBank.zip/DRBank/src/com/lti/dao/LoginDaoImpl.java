package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Account_details;
import com.lti.model.Banker_Info;
import com.lti.model.Internet_banking;
import com.lti.model.dr_Customers;

@Repository
public class LoginDaoImpl implements LoginDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private Internet_banking ib;
	

	//login 
	public List<Internet_banking> UserLogin(String username, String password) {
		TypedQuery<Internet_banking> tquery= entityManager.createQuery("Select i From Internet_banking i where i.username=:u AND i.password=:p AND i.lock_status=0",Internet_banking.class);
		tquery.setParameter("u", username);
		tquery.setParameter("p", password);
		List<Internet_banking> userlist = tquery.getResultList();
		return userlist;
	}

	
	//Admin Login
	public int AdminLogin(String email, String password) {
		TypedQuery<Banker_Info> tquery= entityManager.createQuery("Select b From Banker_Info b where b.banker_email=:u AND b.banker_password=:p",Banker_Info.class);
		tquery.setParameter("u", email);
		tquery.setParameter("p", password);
		List<Banker_Info> userlist = tquery.getResultList();
		return userlist!=null?userlist.size():0;
	}
	
	//Change Password
	@Override
	public int setUserPassword(String password, String username) {
		ib=entityManager.find(Internet_banking.class, username);
		ib.setPassword(password);
		ib.setLock_status(0);
		entityManager.merge(ib);
		return 1;
	}
	
	//Forgot Passowrd
	@Override
	public Internet_banking getusername(long accno) {
		TypedQuery<Account_details> tquery=entityManager.createQuery("Select a from Account_details a where a.acc_no=:a", Account_details.class);
		tquery.setParameter("a", accno);
		Account_details drcust=tquery.getSingleResult();
		long id=drcust.getCustomer_id();
		TypedQuery<Internet_banking> tquer= entityManager.createQuery("Select i From Internet_banking i where i.customer_id=:id",Internet_banking.class);
		tquer.setParameter("id",id);
		Internet_banking ib=tquer.getSingleResult();
		
		return ib;
	}

	@Override
	public String getemail(long customer_id) {
		dr_Customers cust=entityManager.find(dr_Customers.class, customer_id);
		return cust.getEmail();
	}

	//Lock After 3times
	@Override
	public long setLockStatus(String username) {
		ib=entityManager.find(Internet_banking.class, username);
		ib.setLock_status(1);
		return ib.getCustomer_id();		
	}


	

}

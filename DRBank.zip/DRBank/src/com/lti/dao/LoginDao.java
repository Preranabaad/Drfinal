package com.lti.dao;

import java.util.List;

import com.lti.model.Banker_Info;
import com.lti.model.Internet_banking;

public interface LoginDao {
	
	//Login
	public List<Internet_banking> UserLogin(String username,String password);
	
	//Admin Login
	public int AdminLogin(String email,String password);
	
	//Change Password
	public int setUserPassword(String password, String username);
	
	//Forgot Password
	public Internet_banking getusername(long accno);
	public String getemail(long customer_id);
	
	//Lock after 3times
	public long setLockStatus(String username);
}
